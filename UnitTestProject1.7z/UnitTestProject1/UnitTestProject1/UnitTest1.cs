﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Runtime.Remoting.Messaging;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]

        //BDD = chováním řízený vývoj
        //TDD = testování řízen projekt
        public void TestMethodPos()
        {
            /*podmínky pro úspěch aplikace*/
        }
        public void TestMethodNeg()
        {
        }
    
    }
}
