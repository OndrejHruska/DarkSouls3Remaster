﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UnitTestProject3
{
    public class HerniPostava
    {
        private string jmeno;
        private int level = 1;
        private  int poziceX = 0;
        private  int poziceY = 0;


        public HerniPostava(string jmeno)
        {
            if (jmeno.Length > 10)
            {
                MessageBox.Show("Příliš dlouhé jméno!");
            }
            else
            {
                this.jmeno = jmeno;
            }
        }

        public void ZmenaPozice(EventArgs e)
        {
            MouseEventArgs e2 = (MouseEventArgs)e;
            this.poziceX = e2.X;
            this.poziceY = e2.Y; 
        }

        public override string ToString()
        {
            return $"Jméno: {jmeno}, Level: {level}, Pozice X: {poziceX}, Pozice Y: {poziceY}";
        }
    }
}
