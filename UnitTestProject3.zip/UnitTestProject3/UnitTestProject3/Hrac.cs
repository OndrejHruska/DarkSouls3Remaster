﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;


namespace UnitTestProject3
{
    internal class Hrac
    {
        public int oblicej = 0;
        public int vlasy = 0;
        public int vlasyBar = 0;
        public int XP = 0;
        public int x = 0;
        public int y = 0;
        public string jmeno = string.Empty;
        public int LVL = 1;


        public void XPplus(int pridejHodnotu)
        {
            XP += pridejHodnotu;
            LevelUp();
        }

        public void LevelUp()
        {
            int exponencialniLVL = 100 * this.LVL;
            if (this.XP >= exponencialniLVL)
            {
                this.XP -= exponencialniLVL;
                this.LVL++;
            }
        }
        public void DelkaJmena(string jmeno)
        {
            this.jmeno = jmeno;
        }
    }
}
