﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject3
{
    internal class Hrac
    {
        public int oblicej = 0;
        public int vlasy = 0;
        public int vlasyBar = 0;
        public int XP = 0;
        public int x = 0;
        public int y = 0;
        public string jmeno = "";
        public int LVL;


        public void XPplus(int pridejHodnotu)
        {
            
        }




    }
}
