﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject3
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodOblicejPos()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.oblicej,0);
        }
        [TestMethod]
        public void TestMetodVlasyPos()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.vlasy, 0);

        }
        [TestMethod]
        public void TestMetodVlasyBar()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.vlasyBar, 0);

        }
        [TestMethod]
        public void TestMetodOverXP()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.XP, 0);

        }
        [TestMethod]
        public void PridejXP()
        {
            Hrac Jozo = new Hrac();
            Jozo.XPplus(50);
            Assert.AreEqual(Jozo.XP, 50);

        }
        [TestMethod]
        public void PridejLVL()
        {
            Hrac Jozo = new Hrac();
            Jozo.XPplus(100);
            Assert.AreEqual(Jozo.LVL, 2);
            Assert.AreEqual(Jozo.XP, 0);
            

        }

        [TestMethod]
        public void TestX()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.x, 0);

        }
        [TestMethod]
        public void TestY()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.y, 0);

        }
        [TestMethod]
        public void DelkaJmena()
        {
            Hrac Jozo = new Hrac();
            Assert.IsTrue(Jozo.jmeno.Length < 10 && Jozo.jmeno.Length > 0);

        }

        [TestMethod]
        public void TestLVL()
        {
            Hrac Jozo = new Hrac();
            Assert.AreEqual(Jozo.LVL, 1);

        }
    }
}
